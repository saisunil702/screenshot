package dbcon;
import java.sql.Connection;
import java.sql.DriverManager;

public class MyCon {

	public static Connection getMycon()
	{
		Connection con=null;
		try
		{
			Class.forName("oracle.jdbc.OracleDriver");  
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","servletapp1","servlet1");  
			      
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	
	return con;
}
	}