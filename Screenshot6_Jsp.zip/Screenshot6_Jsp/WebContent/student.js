function fun1()
{
	var name=document.f1.n1.value;
	var uid=document.f1.n2.value;
	var pwd=document.f1.n3.value;
    var add=document.f1.n4.value;
	if(name=="")
	{
		document.getElementById('s1').innerHTML='*please fill ur name';
		document.getElementById('s1').style.color='red';
		return false;
	}
	if(uid=="")
	{
		document.getElementById('s2').innerHTML="*please fill ur userid";
		document.getElementById('s2').style.color="red";
		return false;
	}
	if(pwd=="")
	{
		document.getElementById('s3').innerHTML="*please fill ur password";
		document.getElementById('s3').style.color="red";
		return false;
	}
	if(add=="")
	{
		document.getElementById('s4').innerHTML='*please fill ur name';
		document.getElementById('s4').style.color='red';
		return false;
	}
	else
	{
		
		alert("Ur data is accepted");
		return true;
	}
}
function fun2()
{
	var x=confirm("Are you sure to reset");
	if(x==true)
	{
		return true;
	}
	else
	{
		return false;
	}
}
function fun3()
{
	
	var uid=document.f1.n1.value;
	var pwd=document.f1.n2.value;
    
	
	if(uid=="")
	{
		document.getElementById('s1').innerHTML="*please fill ur userid";
		document.getElementById('s1').style.color="red";
		return false;
	}
	if(pwd=="")
	{
		document.getElementById('s2').innerHTML="*please fill ur password";
		document.getElementById('s2').style.color="red";
		return false;
	}
	
	else
	{
		
		alert("Ur data is accepted");
		return true;
		
	}
}
function fun4()
{
	var x=confirm("Are you sure to reset");
	if(x==true)
	{
		return true;
	}
	else
	{
		return false;
	}
}
function fun5()
{
	var uid=document.f1.n1.value;
	var pwd=document.f1.n2.value;
	var npwd=document.f1.n3.value;
    var cpwd=document.f1.n4.value;
	if(uid=="")
	{
		document.getElementById('s1').innerHTML='*please fill ur userid';
		document.getElementById('s1').style.color='red';
		return false;
	}
	if(pwd=="")
	{
		document.getElementById('s2').innerHTML="*please fill ur password";
		document.getElementById('s2').style.color="red";
		return false;
	}
	if(npwd=="")
	{
		document.getElementById('s3').innerHTML="*please fill ur password";
		document.getElementById('s3').style.color="red";
		return false;
	}
	if(cpwd=="")
	{
		document.getElementById('s4').innerHTML='*please fill ur name';
		document.getElementById('s4').style.color='red';
		return false;
	}
	if(npwd!=cpwd)
	{
		document.getElementById('s4').innerHTML="*please check ur password";
		document.getElementById('s4').style.color="red";
		return false;
	}
	else
	{
		
		alert("Ur data is accepted");
		return true;
	}
}
function fun6()
{
	var x=confirm("Are you sure to reset");
	if(x==true)
	{
		return true;
	}
	else
	{
		return false;
	}
}
function fun7()
{
	
	var uid=document.f1.n1.value;
	var pwd=document.f1.n2.value;
   
	
	if(uid=="")
	{
		document.getElementById('s1').innerHTML="*please fill ur userid";
		document.getElementById('s1').style.color="red";
		return false;
	}
	if(pwd=="")
	{
		document.getElementById('s2').innerHTML="*please fill ur password";
		document.getElementById('s2').style.color="red";
		return false;
	}
	
	else
	{
		
		alert("Ur data is accepted");
		return true;
	}
}
function fun8()
{
	var x=confirm("Are you sure to reset");
	if(x==true)
	{
		return true;
	}
	else
	{
		return false;
	}
}
